<?php 
include("server.php");

if (!isset( $_SESSION['username'])){
     echo ("<SCRIPT LANGUAGE='JavaScript'>
  window.location.href='index.php';
 </SCRIPT>");
}
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Bank Of Rishikesh</title>
<link href="style.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
function ctck()
{
var sds = document.getElementById("dum");

}

function redirectToUser(){
        alert("This action is not allowed")
    }

</script>

</head>

<body>

<div id="top_links">


<?php 
include("usertop.php");
?>

<table cellpadding="0" cellspacing="0" id="content1"><tr align="justify">
	<td class="con" valign="top">
        	<div id="heade1"><h1>Results</h1></div>
        <p>This is a bank which focuses on consistency and security. We aim to give you better results every time you check us out. We are always happy to help our customers and keep them in good spirits about their money.<br><br>
        We strive for integrity. One of our core values is Results, which means we are always eager to give you the best results through our services. We are glad to see you here.
      

</p>
    </td>
    
    <td class="con" valign="top">
    	<div id="heade2"><h1>Opportunities</h1></div>
        <p> This bank allows an ocean of opportunities, to begin with, here we can assure about the consistency. The opportunities we provide here are vast, the bank enables you to check your balance and transfer funds to another user within our bank.<br><br>

Reasons you should opt us begin with all the opportunities you get while being an active user within the bank. We provide fast and easy access to information and user friendly experience. 

</p>
    </td>
    
    <td class="con" valign="top">
    	<div id="heade3"><h1>Solutions</h1></div>
        <p>We are a one stop access to all your problems. With a very responsive team, we aim to provide solutions according to your usage and your preferences. We are a user friendly bank as we have focused on making the website as user friendly as possible. <br>
        
        We make sure you will not be disappointed with the Bank Of Rishikesh experience.
        
    </td>
</tr></table>

<table style="width:897px; background:#FFFFFF; margin:0 auto;">
	<td width="299" valign="top" style="border-right:#666666 1px dotted;">
    	<div id="services"><h1>Reach our creators through email</h1><br>
		    <ul>
        	<li><a href="mailto:iamsurajpurohit@gmail.com">Surya Kant</a></li>
            <li><a href="#">Sagar Kumar </a></li>
            <li><a href="#">Preetam Rana</a></li>
            </ul>
			
       </div>
	</td>
    
    <td width="299" valign="top">
    	<div id="welcome_user" style="font:bold italic 15px/12px Arial, Helvetica, sans-serif; text-align:center; margin-top:25px;"> <h1> WELCOME, USER </h1>
    	<br>
    	<br>
        <h2 style="margin-top:15px"> Your Account Number is </h2>
        <br>
    	<hr>
      <h2><?php echo $accno ?></h2>
        <hr>
        </div>
    </td>
    
    <td width="299" valign="top" style="border-left:#666666 1px dotted;">
   	  <div id="news"><h1>News &amp; Events</h1><br>
      	<div class="img"><img src="images/globe_16.gif" alt="Business"></div>
        <h2>August. 17, 2022.</h2>
        <p>Now users can check their bank balance  at no cost, making it easy to access.</p><br>
        <div class="img"><img src="images/globe_12.gif" alt="Business"></div>
        <h2>August. 25, 2022.</h2>
        <p>Now the users can transfer funds to other users within the bank.</p>
      
      </div>
        	
     </td>
</table>

<?php 
include('footer.php');
?>

</div>

</body>
</html>
