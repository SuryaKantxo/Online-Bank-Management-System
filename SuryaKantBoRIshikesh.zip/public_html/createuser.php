<?php 
include('server.php');
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Open Account</title>
<link href="style.css" rel="stylesheet" type="text/css">


</head>


<body>

<div id="top_links">
  

<?php 
include("admintop.php");
?>



<table style="width:897px; background:#FFFFFF; margin:0 auto;">
<tr >
	<td width="300" valign="top" style="border-right:#666666 1px dotted;">
    	<div id="services"><h1>Reach our creators through email</h1><br>
		    <ul>
        	<li><a href="mailto:iamsurajpurohit@gmail.com">Surya Kant</a></li>
            <li><a href="#">Sagar Kumar </a></li>
            <li><a href="#">Preetam Rana</a></li>
            </ul>
			
       </div>
	</td>
    
    <td width="1200" valign="top">
    	<div id="welcome" style="border-right:#666666 1px dotted;"><h1>OPEN ACCOUNT FORM</h1><br>
    	    <table  align="center" bgcolor="white">
		<tr>
			
		</tr>
		<tr>
			<td>
				<form method="post" action="createuser.php" onsubmit= "return validation();">
				  <table cellspacing="5" cellpadding="3">	
				
					<tr><td>USER NAME:</td><td> <input id="username" type="text" name="username" required/></td></tr>
					<tr><td> GENDER </td>
				   <td> 
					
					Male &nbsp;<input type="radio" name="gender" value="0"> Female &nbsp;<input type="radio" name="gender" value="1" required/>


					</td></tr>

					<tr><td>PASSWORD:</td><td> <input type="password" id="password" name="password" required /></td></tr>
					<tr><td>RE-ENTER PASSWORD:</td><td> <input type="password" id="repassword" name="repassword" required/></td></tr>
					<tr><td>AMOUNT:</td><td> <input type="text" id="amount" name="amount" required/></td></tr>
					
					<tr><td>ADDRESS:</td><td> <input type="text" id="address" name="address" required/></td></tr>
					<tr><td>PHONE:</td><td> <input type="text" id="phone" name="phone" required/></td></tr>
				<?php
			if(isset($_SESSION['admin']))	echo'
				
					<tr><td></td><td><input type="submit" value="SUBMIT" name="reg_admin"> &nbsp;
			';
			else 
			echo'
			<tr><td></td><td><input type="submit" value="SUBMIT" name="reg_user"> &nbsp;
		';	?>	
					<INPUT TYPE=RESET VALUE="CLEAR"></td></tr>
					<input type="text" id="xyz" name="xyz" value="false" hidden>
					</table>
               		</form>
			</td>
		</tr>
	
	</table>
    	   </div>      
    </td>
    
   <td width="299" valign="top">
    	<div id="welcome" style="border-right:#666666 1px dotted;"><h1>Welcome</h1><br>
    	    <center><img src="images/globe_10.gif" alt="business" width="196" height="106"></center><br>
		    <p>Here comes a secure e-bank portal with Bank Of Rishikesh which provides you with a different kinds of services, such as checking your balance, and making fund transfers, also allowing access to closing of account.</p>
	    </div>      
    </td>
             	
    
</tr></table>
    
<?php 
include('footer.php');
?>


</div>
<script type="text/javascript">

	
   function redirectToLogin(){
        alert("YOU ARE NOT LOGGED IN!!");
    }

function validation(){

		var name= document.getElementById("username").value;
		var phonen= document.getElementById("phone").value;
		var amt= document.getElementById("amount").value;
		var pwd= document.getElementById("password").value;			
		var cpwd= document.getElementById("repassword").value;
		var add= document.getElementById("address").value;
        //password expression code
		var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
		var letters = /^[A-Za-z]+$/;
		var filter_phone = /^(\+\d{1,3}[- ]?)?\d{10}$/;

		
		 if(!letters.test(name))
		{
			alert('User Name field required only alphabet characters');
			return false;
		}
		else if(document.getElementById("password").value.length < 6)
		{
			alert ('Password minimum length is 6');
			return false;
		}
		else if(document.getElementById("password").value.length > 12)
		{
			alert ('Password max length is 12');
			return false;
		}
		else if(!pwd_expression.test(pwd))
		{
			alert ('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
			return false;
		}
		else if(pwd != cpwd)
		{
			alert ('Password not Matched');
			return false;
		}
		else if(amt<500)
		{
			alert('Minimum Amount is ₹500');
			return false;
		}
		else if (!filter_phone.test(phonen))
		{
			alert('Invalid Phone Number');
			return false;
		}
		else if(document.getElementById("address").value=="")
		{
			alert("Enter Address");
			return false;
		}
		else 
		{				                            
		    return true;
		}
	}


</script>
</body>
</html>