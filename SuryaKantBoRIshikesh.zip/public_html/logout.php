<?php
session_start();
ob_start();

    session_destroy();
    unset($_SESSION['username']);
    unset($_SESSION['admin']);
    header('location:index.php');
?>