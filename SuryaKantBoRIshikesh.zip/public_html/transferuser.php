<?php 
include("server.php");

if (!isset( $_SESSION['username'])){
     echo ("<SCRIPT LANGUAGE='JavaScript'>
  window.location.href='index.php';
 </SCRIPT>");
}
?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<SCRIPT LANGUAGE="JavaScript">
function redirect(){
    alert("This action is not allowed");
}

</SCRIPT>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Global Banking ..</title>
<link href="style.css" rel="stylesheet" type="text/css">
<script type="text/javascript">

function redirect(){
	alert("Action Not Allowed");
}
</script>

</head>

<body>

<div id="top_links">
  
<?php 
include("usertop.php");
?>



<table style="width:800px; background:#FFFFFF; margin:0 auto;">
<tr >
	<td width="100" valign="top" style="border-right:#666666 1px dotted;">
    	<div id="services"><h1>Reach our creators through email</h1><br>
		    <ul>
        	<li><a href="mailto:iamsurajpurohit@gmail.com">Surya Kant</a></li>
            <li><a href="#">Sagar Kumar </a></li>
            <li><a href="#">Preetam Rana</a></li>
            </ul>
			
       </div>
	</td>
    
    <td width="450" valign="top">
    	<div id="welcome" style="border-right:#ffffff 1px dotted;"><h1>TRANSFER FORM</h1><br>
    	    <table align="center" bgcolor="white">
		<tr>
			
		</tr>
		<tr>
			<td>
				<form name=F1 method= "POST" onSubmit="return dil(this)" action="transferuser.php" >
				    <table cellspacing="5" cellpadding="3">
				    <tr><td>ACCOUNT NO:</td><td> <input type="text" name="accountno" value =<?php echo $accno ?>></td></tr>
					<tr><td>TARGET ACCOUNT NO:</td><td><input type="text" name="taccountno"/></td></tr>
					<tr><td>AMOUNT:</td><td> <input type="text" name="tamount"/></td></tr>
					<tr><td>PASSWORD:</td><td> <input type="password" name="password"/></td></tr>
					<tr><td></td><td><input type="submit" name="truser" value="Submit"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<INPUT TYPE=RESET VALUE="CLEAR"></td></tr>
					</table>
		    		</form>
			</td>
		</tr>
	</table>
    	   </div>      
    </td>
    
   <td width="250" valign="top">
    	<div id="welcome" style="border-left:#666666 1px dotted;"><h1>Welcome</h1><br>
    	    <center><img src="images/globe_10.gif" alt="business" width="196" height="106"></center><br>
		    <p>Here comes a secure e-bank portal with Bank Of Rishikesh which provides you with a different kinds of services, such as checking your balance, and making fund transfers, also allowing access to closing of account.</p>
	    </div>      
    </td>
             	
    
</tr></table>
    
<?php 
include('footer.php');
?>

</div>

</body>
</html>
