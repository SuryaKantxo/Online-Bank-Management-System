<?php 
include("server.php");

if (!isset( $_SESSION['admin'])){
     echo ("<SCRIPT LANGUAGE='JavaScript'>
  window.location.href='index.php';
 </SCRIPT>");
}

if(!isset($name))
$name="";
if(!isset($accountno) || !isset($amount)){
    $accountno="";
    $amount="";
}
?>
<?php error_reporting (E_ALL ^ E_NOTICE); ?>

<html>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Balance</title>
<link href="style.css" rel="stylesheet" type="text/css">
<div id="top_links">
<?php
include("admintop.php");
?>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h2>Users' Details</h2>

<table>
  <tr>
    <th>Account_Number*</th>
    <th>username</th>
    <th>gender</th>
    <th>amount</th>
    <th>address</th>
    <th>phone</th>
  </tr>
  <?php
  for($i=0;$i<=$j;++$i){
      echo '<tr>';
      echo '<td>'.$rows[$i]["Account_Number"].'</td>';
      echo '<td>'.$rows[$i]["username"].'</td>';
      echo '<td>'.$rows[$i]["gender"].'</td>';
      echo '<td>'.$rows[$i]["amount"].'</td>';
      echo '<td>'.$rows[$i]["address"].'</td>';
      echo '<td>'.$rows[$i]["phone"].'</td>';
      echo '<tr>';
  }
  ?>
</table>
<?php
include("footer.php");
?>
</div>

</body>
</html>