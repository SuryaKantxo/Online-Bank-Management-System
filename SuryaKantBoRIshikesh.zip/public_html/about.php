<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Bank Of Rishikesh</title>
<link href="style.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
function ctck()
{
var sds = document.getElementById("dum");

}
</script>

</head>

<body>

<div id="top_links">
  <h1 style="color: white;margin-left: 33%;">WELCOME, ADMIN</h1>

<?php 
include("admintop.php");
?>

<table cellpadding="0" cellspacing="0" id="content1"><tr align="justify">
	<td class="con" valign="top">
    	<div id="heade1"><h1>Results</h1></div>
         <p>This is a bank which focuses on consistency and security. We aim to give you better results every time you check us out. We are always happy to help our customers and keep them in good spirits about their money.<br><br>
        We strive for integrity. One of our core values is Results, which means we are always eager to give you the best results through our services. We are glad to see you here.

</p>
    </td>
    
    <td class="con" valign="top">
    	<div id="heade2"><h1>Opportunities</h1></div>
        <p> This bank allows an ocean of opportunities, to begin with, here we can assure about the consistency. The opportunities we provide here are vast, the bank enables you to check your balance and transfer funds to another user within our bank.<br><br>

Reasons you should opt us begin with all the opportunities you get while being an active user within the bank. We provide fast and easy access to information and user friendly experience. 
 

</p>
    </td>
    
    <td class="con" valign="top">
    	<div id="heade3"><h1>Solutions</h1></div>
         <p>We are a one stop access to all your problems. With a very responsive team, we aim to provide solutions according to your usage and your preferences. We are a user friendly bank as we have focused on making the website as user friendly as possible. <br>
        
        We make sure you will not be disappointed with the Bank Of Rishikesh experience.
        
</tr></table>

<table style="width:897px; background:#FFFFFF; margin:0 auto;"><tr align="justify">
    
    <td width="299" valign="top">
        



    	<div id="welcome_admin" style="border-right:#666666 1px dotted; text-align: center;  margin-top: 2%;font-family: Arial;">
    	    <h2>Watch this video to understand how our bank works.</h2><hr>
    	    <iframe width="560" height="315" src="https://www.youtube.com/embed/sbvAAezbCKU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe><hr>
    	    
    	    <h2><u>Meet the creators</u></h2> <br>
    	    <h3>We are students of Omkarananda Institue of Management and Technology, Rishikesh. We all are currenty enrolled in BSc Information Technology and we are currently in our 6th semester. This website was built as a final-year project based on Online Bank Management System.We hope that the project does not disappoint and we have made this in full amount of our knowledge. We hope that you like the website.</h3><br>
    	    <h4>Surya Kant</h4>
    	     <h4>Sagar Kumar</h4>
    	      <h4>Preetam Rana</h4>
    	    
        </div>
    </td>
    
</tr></table>

<?php 
include('footer.php');
?>

</div>

</body>
</html>