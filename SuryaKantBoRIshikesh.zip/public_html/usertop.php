<div id="header">

	<h1>BANK OF RISHIKESH<span class="style1"></span></h1>
    <h2>Always with you</h2>	
    <A href="welcomeUser.php"><IMG SRC="images/home-button-icon-png-23.gif" height="50px" width="50px"></IMG></A>	
</div>
<script>
function redirectToUser(){
  alert("Action Not Allowed")
}
</script>
<div id="navigation">
    <ul>
    <li><a onclick="redirectToUser()">NEW ACCOUNT</a></li>
    <li><a href="Totalbalanceuser.php">BALANCE</a></li>
    <li><a onclick="redirectToUser()">DEPOSIT</a></li>
    <li><a onclick="redirectToUser()">WITHDRAW</a></li>
    <li><a href="transferuser.php">TRANSFER</a></li>
    <li><a href="closeac.php">CLOSE A/C</a></li>
    <li><a href="about.php">ABOUT US</a></li>
    </ul>
</div>