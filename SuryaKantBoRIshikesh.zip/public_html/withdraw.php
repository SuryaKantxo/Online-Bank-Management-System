<?php 
include("server.php");

if (!isset( $_SESSION['admin'])){
     echo ("<SCRIPT LANGUAGE='JavaScript'>
  window.location.href='index.php';
 </SCRIPT>");
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<SCRIPT LANGUAGE="JavaScript">
function dil(form)
{
   for(var i=0; i<form.elements.length; i++)
   {
		if(form.elements[i].value == "")
		{
		   alert("Fill out all Fields")
		   document.F1.accountno.focus()
		   return false
		}
   }

   if(isNaN(document.F1.accountno.value))
   {
       alert("A/C No.  must  be  number & can't be null")
	   document.F1.accountno.value=""
	   document.F1.accountno.focus()
	   return false
   }

   if(!isNaN(document.F1.username.value))
   {
       alert("User Name  must  be  char's & can't be null")
	   document.F1.username.value=""
	   document.F1.username.focus()
	   return false
   }

   if(!isNaN(document.F1.password.value))
   {
       alert("Password  must  be  char's & can't be null")
	   document.F1.password.value=""
	   document.F1.password.focus()
	   return false
   }

   if(isNaN(document.F1.amount.value))
   {
       alert("Amount  must  be  number & can't be null")
	   document.F1.amount.value=""
	   document.F1.amount.focus()
	   return false
   }

   return true   
}
</SCRIPT>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Global Banking ..</title>
<link href="style.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
function ctck()
{
var sds = document.getElementById("dum");

}
</script>

</head>

<body>

<div id="top_links">
  

<?php 
include("admintop.php");
?>



<table style="width:897px; background:#FFFFFF; margin:0 auto;">
<tr >
	<td width="300" valign="top" style="border-right:#666666 1px dotted;">
    	<div id="services"><h1>Reach our creators through email</h1><br>
		    <ul>
        	<li><a href="mailto:iamsurajpurohit@gmail.com">Surya Kant</a></li>
            <li><a href="#">Sagar Kumar </a></li>
            <li><a href="#">Preetam Rana</a></li>
            </ul>
			
       </div>
	</td>
    
    <td width="1200" valign="top">
    	<div id="welcome" style="border-right:#ffffff 1px dotted;"><h1>WITHDRAW FORM</h1><br>
    	    <table  align="center" bgcolor="white">
		<tr>
		
		</tr>
		<tr>
			<td>
			<div>
			
			 </div>
				<form name=F1 method="post" action="withdraw.php" >
				   <table cellspacing="5" cellpadding="3">	
				   <tr><td> ACCOUNT NO: </td><td><input type="text" name="accountno"/></td></tr>
				   <tr><td>AMOUNT:</td><td> <input type="text" name="amount"/></td></tr>
				   <tr><td><h1>ADMIN</h1></td><td></td></tr>
					<tr><td>USER NAME: </td><td><input type="text" name="username"/></td></tr>
					<tr><td>PASSWORD:</td><td> <input type="password" name="password"/></td></tr>
					
				
					<tr><td></td><td><input type="submit" value="Submit" name="withdraw"/>
					<INPUT TYPE=RESET VALUE="CLEAR"></td></tr>
					</table>
					</form>
			</td>
		</tr>
	</table>
    	   </div>      
    </td>
    
    <td width="297" valign="top">
    	<div id="welcome" style="border-left:#666666 1px dotted;"><h1>Welcome</h1><br>
    	    <center><img src="images/globe_10.gif" alt="business" width="196" height="106"></center><br>
		    <p>Here comes a secure e-bank portal with Bank Of Rishikesh which provides you with a different kinds of services, such as creating an account, checking balance, making deposits, withdrawls, making fund transfers also allowing access to closing of account.</p>
	    </div>      
    </td>
            	
    
</tr></table>
    
<?php 
include('footer.php');
?>

<script type="text/javascript">
document.onload = ctck();
</script>
</div>

</body>
</html>
