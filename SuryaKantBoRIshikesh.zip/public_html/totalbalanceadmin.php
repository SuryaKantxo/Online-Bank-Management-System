<?php 
include("server.php");

if (!isset( $_SESSION['admin'])){
     echo ("<SCRIPT LANGUAGE='JavaScript'>
  window.location.href='index.php';
 </SCRIPT>");
}

if(!isset($name))
$name="";
if(!isset($accountno) || !isset($amount)){
    $accountno="";
    $amount="";
}
?>

<html>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Balance</title>
<link href="style.css" rel="stylesheet" type="text/css">
<script type="text/javascript">



function redirect(){
  alert("Action Not Allowed")
}
</script>

</head>

<body>

<div id="top_links">
  
<?php 
include("admintop.php");
?>


<table style="width:897px; background:#FFFFFF; margin:0 auto;">

	<td width="300" valign="top" style="border-right:#666666 1px dotted;">
        	<div id="services"><h1>Reach our creators through email</h1><br>
		    <ul>
        	<li><a href="mailto:iamsurajpurohit@gmail.com">Surya Kant</a></li>
            <li><a href="#">Sagar Kumar </a></li>
            <li><a href="#">Preetam Rana</a></li>
            </ul>
			
       </div>
	</td>
	
	<td  id="Menu" width="299" valign="top">
    	<div id= "welcome" style="border-right:#ffffff 1px dotted;"><h1>MENU</h1><br>
			<table align="center" valign="middle" bgcolor="white">

      <tr>
		
		</tr>
		<tr>
			<td>
			<div>
			
			 </div>
				   <table cellspacing="5" cellpadding="3" valign="middle">
				     <br>
				     <br>
					<tr><td><input type="button" onclick="showallinfo()" value=" GET ALL USER TABLES"> </td><td></td></tr>
					
					<tr><td><br><input type="button" onclick="showuserinfo()" value="GET SINGLE USER INFO"></td><td></td></tr>
					</table>

      </table>
      
      
    </td>
        </div>
            

</td>
	
    
    <td  id="Userinfo" width="299" valign="top">
    	<div id= "welcome" style="border-right:#ffffff 1px dotted;"><h1>ACCOUNT INFO</h1><br>
			<table align="center" valign="middle" bgcolor="white">

      <tr>
		
		</tr>
		<tr>
			<td>
			<div>
			
			 </div>
				<form name=F1 id="F1" method="post" action="totalbalanceadmin.php" >
				   <table cellspacing="5" cellpadding="3">	
				   <tr><td>Account Number: </td><td><input type="text" name="accno" required></td></tr>
				   <tr><td><h1>ADMIN</h1> </td><td></td></tr>
					<tr><td>USERNAME </td><td><input type="text" name="username" required></td></tr>
					<tr><td>PASSWORD:</td><td> <input type="password" name="password" required></td></tr>
				
					<tr><td></td><td><input type="submit" value="SUBMIT" name="getbalanceadmin">
					<INPUT TYPE=RESET VALUE="CLEAR"></td></tr>
					<tr><td><input type="button" onclick="back()" value=" GO BACK "></td><td></td></tr>
					</table>
					</form>
					

      </table>
      
      <table id="info" cellspacing="5" cellpadding="3">	
				<tr><td>Username:</td><td> <h2><?php echo $name ?></h2></td></tr>
                <tr><td>Account Number:</td><td> <h2><?php echo $accountno ?></h2></td></tr>
                <tr><td>Amount:</td><td> <h2><?php echo $amount?></h2> </td></tr>
                

				</table>
      
    </td>
        </div>
            
            </td>
            
            

    <td  id="Allinfo" width="299" valign="top">
    	<div id= "welcome" style="border-right:#ffffff 1px dotted;"><h1>ALL ACCOUNT INFO</h1><br>
			<table align="center" valign="middle" bgcolor="white">

      <tr>
		
		</tr>
		<tr>
			<td>
			<div>
			
			 </div>
				
				   <table cellspacing="5" cellpadding="3">
				    <form method="post" action="userdetailstable.php">	
					<tr><td>USERNAME </td><td><input type="text" name="username" required></td></tr>
					<tr><td>PASSWORD:</td><td> <input type="password" name="password" required></td></tr>
					<tr><td></td><td><input type="submit" value="      GO     " name="gettable"></td></tr>
					<tr><td><input type="button" onclick="back()" value=" GO BACK "></td><td></td></tr>
					</form>
					</table>

      </table>
      
      
    </td>
        </div>
            

</td>



 

			
        <td width="299"  valign="top">
    	<div id="welcome" style="border-left:#666666 1px dotted;"><h1>Welcome</h1><br>
    	    <center><img src="images/globe_10.gif" alt="business" width="196" height="106"></center><br>
		     <p>Here comes a secure e-bank portal with Bank Of Rishikesh which provides you with a different kinds of services, such as checking your balance, and making fund transfers, also allowing access to closing of account.</p>
	    </div>      
    </td>
</table>

<?php 
include('footer.php');
?>

<script>
    function showallinfo(){
  
        document.getElementById('Allinfo').style.display = 'block';
        document.getElementById('Menu').style.display = 'none';
    }
    function showuserinfo(){
  
        document.getElementById('Menu').style.display = 'none';
        document.getElementById('Userinfo').style.display = 'block';
    }
    
    
   
    
    function back(){
        document.getElementById('Menu').style.display = 'block';
        document.getElementById('Allinfo').style.display = 'none';
         document.getElementById('Userinfo').style.display = 'none';
    }
    
    function gettable(){
            document.getElementById('Menu').style.display = 'none';
        document.getElementById('Allinfo').style.display = 'none';
         document.getElementById('Userinfo').style.display = 'none';
    }
    document.getElementById('Menu').style.display = 'block';
        document.getElementById('Allinfo').style.display = 'none';
         document.getElementById('Userinfo').style.display = 'none';
    
    <?php
      if(isset($getbal)){
        echo '
        document.getElementById("Menu").style.display = "none";
        document.getElementById("Userinfo").style.display = "block";
        ';
      }
    ?>
    
</script>


</div>

</body>
 
	
</html>


