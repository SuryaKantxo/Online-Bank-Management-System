<?php 
include("server.php");
if (!isset($_SESSION['username'])){
     echo ("<SCRIPT LANGUAGE='JavaScript'>
  window.location.href='index.php';
 </SCRIPT>");
}
?>

<html>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Global Banking ..</title>
<link href="style.css" rel="stylesheet" type="text/css">
<script type="text/javascript">

function redirect(){
  alert("Action Not Allowed")
}
</script>

</head>

<body>

<div id="top_links">
  

<?php 
include("usertop.php");
?>



<table style="width:897px; background:#FFFFFF; margin:0 auto;">

	<td width="300" valign="top" style="border-right:#666666 1px dotted;">
     <div id="services"><h1>Reach our creators through email</h1><br>
		    <ul>
        	<li><a href="mailto:iamsurajpurohit@gmail.com">Surya Kant</a></li>
            <li><a href="#">Sagar Kumar </a></li>
            <li><a href="#">Preetam Rana</a></li>
            </ul>
			
			
       </div>
	</td>
    
    <td width="1200" valign="top">
    	<div id= "welcome" style="border-right:#ffffff 1px dotted;"><h1>ACCOUNT INFO</h1><br>
			<table align="center" valign="middle" bgcolor="white">

      <tr>
		
		</tr>
		<tr>
			<td>
			<div>
			
			 </div>

      </table>
      
      <table id="info" cellspacing="5" cellpadding="3" align:"center">	
				
				<br>
				<br>
				<tr><td><h1>Username:</h1></td><td> <h2><?php echo $username ?></h2> </td></tr>
                <tr><td><h1> Account Number:</h1></td><td> <h2><?php echo $accno ?></h2></td></tr>
                <tr><td><h1>Amount:</h1></td><td> <h2><?php echo $amount?></h2> </td></tr>
            
                

				</table>
      
    </td>
        </div>



 

			
        <td width="299" valign="top">
    	<div id="welcome" style="border-left:#666666 1px dotted;"><h1>Welcome</h1><br>
    	    <center><img src="images/globe_10.gif" alt="business" width="196" height="106"></center><br>
		    <p>Here comes a secure e-bank portal with Bank Of Rishikesh which provides you with a different kinds of services, such as checking your balance, and making fund transfers, also allowing access to closing of account.</p>
	    </div>      
    </td>
</table>

<?php 
include('footer.php');
?>

</body>
 
	
</html>