<?php 
session_start();
ob_start();

// initializing variables
$username = "";
$email    = "";
$errors = array();

$servername = "localhost"; 
    $hostusername = "id19507967_root"; 
    $hostpassword = "Suryakant123@";
    $database = "id19507967_bank_of_rishikesh";
    
    $mysqli = @new mysqli($servername, $hostusername, $hostpassword, $database);
    
// connect to the database
$db =  mysqli_connect($servername, 
         $hostusername, $hostpassword, $database);


         
if($mysqli-> ping())
{
    print("Connection OK");
}
else{
    print("NOT connected");
}
// REGISTER USER
if (isset($_POST['reg_user'])) {
    // receive all input values from the form
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password_1 = mysqli_real_escape_string($db, $_POST['password']);
    $password_2 = mysqli_real_escape_string($db, $_POST['repassword']);
    $gender= mysqli_real_escape_string($db,$_POST['gender']);
    $amount= mysqli_real_escape_string($db, $_POST['amount']);
    $address= mysqli_real_escape_string($db, $_POST['address']);
    $phone = mysqli_real_escape_string($db, $_POST['phone']);
    echo "<h1>REGISTER USER</h1>";
  
    // first check the database to make sure 
    // a user does not already exist with the same username and/or email
    $user_check_query = "SELECT * FROM user WHERE username='$username' OR phone='$phone' LIMIT 1";
    $result = mysqli_query($db, $user_check_query);
    $user = mysqli_fetch_assoc($result);
    
    if ($user) { // if user exists
      
  
      if ($user['phone'] === $phone) {
        array_push($errors, "Phone Number already exists");
        echo "<h1>CHECK MULTIPLE USER PHONE ALREADY EXIST</h1>";
      }
    }
    
    // Finally, register user if there are no errors in the form
    if (count($errors) == 0) {
        $userpassword = md5($password_1);//encrypt the password before saving in the database
        echo "<h1>ENCRYPTION</h1>";
        $query = "INSERT INTO user (username, gender,password ,amount,address,phone) 
        VALUES('$username', '$gender', '$userpassword','$amount','$address','$phone')";
        if(!mysqli_query($db, $query)){
            array_push($errors,  mysqli_error($db));
          echo $errors;
        }
        
                  echo "<h1>DATABASE INJECTION</h1>";
        mysqli_query($db, $query);
        $_SESSION['username'] = $username;
        $_SESSION['success'] = "You are now logged in";
        header('location: welcomeUser.php');
    }
  }
  
  /*
  
 $query = "INSERT INTO user (username, gender,password ,amount,address,phone) 
        VALUES('dffdf', '0', 'Bha1@12','599','Syanoyr','7906731098')";
        if(!mysqli_query($db, $query)){
            array_push($errors,  mysqli_error($db));
          echo $errors;
        }
                  */
?>
