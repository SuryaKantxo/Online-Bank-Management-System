<div id="header">
	<h1>BANK OF RISHIKESH<span class="style1"></span></h1>
    <h2>Always with you</h2>	
    <A href="welcomeAdmin.php"><IMG SRC="images/home-button-icon-png-23.gif" height="50px" width="50px"></IMG></A>	
</div>

<div id="navigation">
    <ul>
    <li><a href="createuser.php">NEW ACCOUNT</a></li>
    <li><a href="totalbalanceadmin.php">BALANCE</a></li>
    <li><a href="deposit.php">DEPOSIT</a></li>
    <li><a href="withdraw.php">WITHDRAW</a></li>
    <li><a href="transfer.php">TRANSFER</a></li>
    <li><a href="closeacc.php">CLOSE A/C</a></li>
    <li><a href="about.php">ABOUT US</a></li>
    </ul>
</div>