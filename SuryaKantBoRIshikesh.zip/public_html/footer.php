<div id="footer_top">
  <div id="footer_navigation">
  

  </div>
  <?php
  if(isset($_SESSION['username']) || isset($_SESSION['admin'])){
    echo '<center><a href="logout.php"><img src="images/logout.png" alt="business"  width="80" height="30" ></a></center>';
  }
  ?>
  <br>
  <div id="footer_copyright">
 
    	   
	 <br><p>Here comes a secure e-bank portal with Bank Of Rishikesh which provides you with a different kinds of services such as Opening an account, Money Deposit, Money Transfer, Money withdrawl and much more.</p>
	  
  Copyright © Bank Of Rishikesh<br></div>
</div>
